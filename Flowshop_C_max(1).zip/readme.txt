tail.txt - Taillard(*) reference values
tail.dat - 120 instances, job's processing times i.e.:

120				- number of instances
20 5				- n = 20, m = 5,
 0 54  1 79  2 16  3 66  4 58 	- processing times
 0 83  1  3  2 89  3 58  4 56 
 0 15  1 11  2 49  3 31  4 20 
 0 71  1 99  2 15  3 68  4 85 
 0 77  1 56  2 89  3 78  4 53 
...

(*) Taillard E., Benchmarks for basic scheduling problems, European Journal of Operational Research 64,(1993), 278-285.